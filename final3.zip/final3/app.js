const express = require('express');
const path = require('path');
const cors = require('cors');
const multer = require('multer'); // For file uploads
const fs = require('fs');

const app = express();

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public'))); // Serve static files

// Configure multer for file uploads
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        const uploadDir = path.join(__dirname, 'public/uploads');
        if (!fs.existsSync(uploadDir)) {
            fs.mkdirSync(uploadDir, { recursive: true });
        }
        cb(null, uploadDir);
    },
    filename: (req, file, cb) => {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        cb(null, uniqueSuffix + '-' + file.originalname);
    },
});
const upload = multer({ storage });

// Mock data - Users
const users = [
    {
        image: '/default-user-icon.jpg',
        email: 'user1@example.com',
        password: 'password1',
    },
    {
        image: '/default-user-icon.jpg',
        email: 'user2@example.com',
        password: 'password2',
    },
    {
        image: '/default-user-icon.jpg',
        email: 'user3@example.com',
        password: 'password3',
    },
];

// Route to get users
app.get('/api/users', (req, res) => {
    res.json(users);
});

// Route to add a new user
app.post('/api/users', upload.single('image'), (req, res) => {
    const { email, password } = req.body;
    const image = req.file ? `/uploads/${req.file.filename}` : '/default-user-icon.jpg';

    if (!email || !password) {
        return res.status(400).json({ message: 'Email and password are required.' });
    }

    users.push({ image, email, password });
    res.status(201).json({ message: 'User added successfully', user: { email, image } });
});

// Start server
const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
